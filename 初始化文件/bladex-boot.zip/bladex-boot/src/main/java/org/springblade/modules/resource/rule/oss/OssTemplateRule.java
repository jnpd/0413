/**
 * BladeX Commercial License Agreement
 * Copyright (c) 2018-2099, https://bladex.cn. All rights reserved.
 * <p>
 * Use of this software is governed by the Commercial License Agreement
 * obtained after purchasing a license from BladeX.
 * <p>
 * 1. This software is for development use only under a valid license
 * from BladeX.
 * <p>
 * 2. Redistribution of this software's source code to any third party
 * without a commercial license is strictly prohibited.
 * <p>
 * 3. Licensees may copyright their own code but cannot use segments
 * from this software for such purposes. Copyright of this software
 * remains with BladeX.
 * <p>
 * Using this software signifies agreement to this License, and the software
 * must not be used for illegal purposes.
 * <p>
 * THIS SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY. The author is
 * not liable for any claims arising from secondary or illegal development.
 * <p>
 * Author: Chill Zhuang (bladejava@qq.com)
 */
package org.springblade.modules.resource.rule.oss;

import org.springblade.core.literule.annotation.LiteRuleComponent;
import org.springblade.core.literule.core.RuleComponent;
import org.springblade.core.log.exception.ServiceException;
import org.springblade.core.oss.OssTemplate;
import org.springblade.core.tool.utils.Func;
import org.springblade.modules.resource.rule.context.OssContext;

import static org.springblade.modules.resource.rule.constant.OssRuleConstant.OSS_TEMPLATE_RULE;

/**
 * OSS接口读取校验
 *
 * @author Chill
 */
@LiteRuleComponent(id = OSS_TEMPLATE_RULE, name = "OSS接口读取校验")
public class OssTemplateRule extends RuleComponent {
	@Override
	public void process() {
		OssContext contextBean = this.getContextBean(OssContext.class);
		OssTemplate ossTemplate = contextBean.getOssTemplate();

		if (Func.isEmpty(ossTemplate)) {
			throw new ServiceException("OSS接口读取失败!");
		}
	}
}
