/**
 * BladeX Commercial License Agreement
 * Copyright (c) 2018-2099, https://bladex.cn. All rights reserved.
 * <p>
 * Use of this software is governed by the Commercial License Agreement
 * obtained after purchasing a license from BladeX.
 * <p>
 * 1. This software is for development use only under a valid license
 * from BladeX.
 * <p>
 * 2. Redistribution of this software's source code to any third party
 * without a commercial license is strictly prohibited.
 * <p>
 * 3. Licensees may copyright their own code but cannot use segments
 * from this software for such purposes. Copyright of this software
 * remains with BladeX.
 * <p>
 * Using this software signifies agreement to this License, and the software
 * must not be used for illegal purposes.
 * <p>
 * THIS SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY. The author is
 * not liable for any claims arising from secondary or illegal development.
 * <p>
 * Author: Chill Zhuang (bladejava@qq.com)
 */
package org.springblade.modules.resource.rule.sms;

import org.springblade.core.literule.annotation.LiteRuleComponent;
import org.springblade.core.literule.core.RuleComponent;
import org.springblade.core.log.exception.ServiceException;
import org.springblade.core.sms.SmsTemplate;
import org.springblade.core.tool.utils.Func;
import org.springblade.modules.resource.pojo.entity.Sms;
import org.springblade.modules.resource.rule.context.SmsContext;

import java.util.Map;

import static org.springblade.modules.resource.rule.constant.SmsRuleConstant.FINALLY_SMS_RULE;

/**
 * Sms后置处理
 *
 * @author Chill
 */
@LiteRuleComponent(id = FINALLY_SMS_RULE, name = "SMS构建后置处理")
public class FinallySmsRule extends RuleComponent {
	@Override
	public void process() {
		String tenantId = this.getRequestData();
		SmsContext contextBean = this.getContextBean(SmsContext.class);
		Map<String, Sms> smsPool = contextBean.getSmsPool();
		Map<String, SmsTemplate> templatePool = contextBean.getTemplatePool();

		if (contextBean.getIsCached()) {
			SmsTemplate template = templatePool.get(tenantId);
			contextBean.setSmsTemplate(template);
		} else {
			Sms sms = contextBean.getSms();
			SmsTemplate template = contextBean.getSmsTemplate();
			if (Func.hasEmpty(template, sms)) {
				throw new ServiceException("SMS接口读取失败!");
			} else {
				templatePool.put(tenantId, template);
				smsPool.put(tenantId, sms);
			}
		}

	}
}
